import { Component, OnInit, ViewChild } from '@angular/core';
import { HealthcareDataService } from '../service/healthcare-data.service';
import { RawData} from '../model/rawdata';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-rawdata',
  templateUrl: './raw-data.component.html',
  styleUrls: ['./raw-data.component.css']
})
export class RawDataComponent implements OnInit {
  rawData: RawData[];
  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['deviceid', 'datatype', 'value', 'timestamp'];
  value = 'Clear me';
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  searchForm: FormGroup = new FormGroup({
    deviceId: new FormControl('', Validators.required),
    startDate: new FormControl('', Validators.required),
    endDate: new FormControl('', Validators.required)
  });

  initializeFormGroup() {
    this.searchForm.setValue({
      deviceId: '',
      startDate: '',
      endDate: ''
    });
  }

  constructor(
    private healthcareService: HealthcareDataService
  ) {  }

  ngOnInit() {
  }

  retrieveRawData(): void {
    this.healthcareService.retrieveRawData(this.searchForm.value).subscribe(
      response => {
        this.rawData = response;
        this.listData = new MatTableDataSource(this.rawData);
        this.listData.paginator = this.paginator;
      },
      error => {
        console.log('Error while retrieving data' + error);
      }
    );
  }

  onClear() {
    this.searchForm.reset();
    this.initializeFormGroup();
  }
}

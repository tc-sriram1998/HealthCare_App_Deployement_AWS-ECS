export class RawData {
    datatype: Datatype;
    deviceid: Deviceid;
    timestamp: Timestamp;
    value: Value;
}

export class Datatype {
    S: String;
}

export class Deviceid {
    S: String;
}

export class Timestamp {
    S: String;
}

export class Value {
    N: Number;
}

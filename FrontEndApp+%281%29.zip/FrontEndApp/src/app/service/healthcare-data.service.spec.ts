import { TestBed } from '@angular/core/testing';

import { HealthcareDataService } from './healthcare-data.service';

describe('FootballDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HealthcareDataService = TestBed.get(HealthcareDataService);
    expect(service).toBeTruthy();
  });
});

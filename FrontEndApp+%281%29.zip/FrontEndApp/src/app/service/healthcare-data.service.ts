import { Injectable } from '@angular/core';
import { RawData, Datatype, Deviceid} from '../model/rawdata';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HealthcareDataService {
  private healthcareServiceURL = 'http://<ALBPublicDNS>/api/raw-data?';

  constructor(private http: HttpClient) { }

  retrieveRawData(searchValue): Observable<RawData[]> {
    return this.http.get<RawData[]>(this.healthcareServiceURL
      +'deviceid=' + searchValue.deviceId
      +'&startdate=' + searchValue.startDate
      +'&enddate=' + searchValue.endDate);
  }

}
